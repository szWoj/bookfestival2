package com.CodeClan.example.bookfestival;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookfestivalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookfestivalApplication.class, args);
	}

}
